IUPACName: diethoxy-(6-methyl-2-propan-2-ylpyrimidin-4-yl)oxy-sulfanylidene-lambda5-phosphane
MolecularFormula: C12H21N2O3PS
ConnectivitySMILES: CCOP(=S)(OCC)OC1=NC(=NC(=C1)C)C(C)C
MolecularWeight: 304.35
Volume3D: 232.1000000000
